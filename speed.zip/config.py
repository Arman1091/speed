class Config:
    DEGUG = True
    SECRET_KEY = 'mlairmsoegles'
    SQLALCHEMY_DATABASE_URI = 'sqlite:///base.db'